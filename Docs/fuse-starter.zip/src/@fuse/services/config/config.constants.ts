import { InjectionToken } from '@angular/core';

export const FUSE_CONFIG = new InjectionToken<any>('FUSE_APP_CONFIG');
